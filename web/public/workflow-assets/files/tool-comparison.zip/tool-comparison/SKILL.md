---
name: tool-comparison
description: "Compare tools on the same input and make missing evidence visible before committing to one. Use for this task: Compare tools."
---

# Compare AI tools on one real task

Compare tools on the same input and make missing evidence visible before committing to one.

## Inputs

Two or three tools, one representative input, official feature and pricing links, must-have constraints, original outputs and your scoring rubric.

## Instructions

1. Write one representative task, one common input and the exact result needed. Set required capabilities and a small scoring rubric before reading vendor claims.
2. Record what each publisher documents, including plan restrictions and the date checked. Label missing details unknown.
3. Run the same input when access is available. Keep the prompt, raw output and observed errors. Mark unavailable trials untested and keep vendor claims separate from observations.
4. Score each observed output against the rubric. Cite one specific example supporting each score and recommend a next action conditional on unresolved requirements.

## Sample request

Compare fictional tools A and B for extracting action items. Three checks: action, owner and deadline. Input: 'Maya will send the brief Friday.' A returned 'send brief / Maya / Friday'; B returned 'send brief / team / Friday'. Both plans and pricing are unknown.

## Example result

A passed 3/3 checks on the example. B passed 2/3 and replaced Maya with 'team.' Trial A on five more notes, including one without a due date. Pricing and plan requirements still need a publisher check.

## Acceptance check

Scores refer to identical test inputs, the recommendation cites at least one observable result and any untested feature or price is labeled.
