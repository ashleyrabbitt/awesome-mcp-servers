---
name: connector-trial
description: "Establish what works in your own account before depending on a connector for a recurring task. Use for this task: Test a connection."
---

# Run a first MCP connector trial

Establish what works in your own account before depending on a connector for a recurring task.

## Inputs

Publisher's setup guide, supported client, intended account or workspace, one known non-sensitive test record and the value you expect to retrieve.

## Instructions

1. Use the publisher's current connection method and sign in through its authorization flow. Record the client and account label, available permissions and the time of the trial. Keep credentials out of the report.
2. Choose one known record with a distinctive title and a reference value. Ask for a read-only lookup that returns the title, value and source link or identifier.
3. Compare the result with the record in the source application. If the lookup fails, check the selected account, resource permissions and client connection before changing the prompt.
4. Classify the result as passed, partial or failed. State exactly what was demonstrated, the mismatch if any, and the next smallest check.

## Sample request

Test a Notion connector on my sample page 'Connector Trial 42'. I entered the line 'Owner: Sam'. Retrieve that page, report the owner and link to it. Leave the source page unchanged. If you lack access, say which step failed.

## Example result

Passed if the returned page link opens the expected record and the owner matches Sam. If the title is found but the owner cannot be read, record partial and verify page access in the connected account.

## Acceptance check

A pass requires both the expected value and a verifiable source identifier. No account password, token or content from unrelated records appears in the report.
