---
name: workflow-handoff
description: "Capture the inputs, tools, review point and recovery steps that a prompt alone would leave out. Use for this task: Hand off a workflow."
---

# Package a repeatable AI workflow

Capture the inputs, tools, review point and recovery steps that a prompt alone would leave out.

## Inputs

Workflow objective, trigger, owner, tools and permissions, example input and output, acceptance criteria, review point and known failure modes.

## Instructions

1. Specify the trigger, owner, required inputs and intended destination. Include a fabricated test input when real records contain private details.
2. Write numbered actions with the expected intermediate output. Identify the step that requires human review before sending, publishing or updating a shared record.
3. Describe what to do with missing fields, duplicate inputs, unavailable tools and partial completion. Keep a completion record so a retry cannot duplicate an external action.
4. Write a dry-run acceptance test with expected output. Ask a teammate to run it using only the handoff, and record the first point where they needed extra context.

## Sample request

Create a handoff for turning an approved webinar transcript into an email draft. Trigger: transcript marked final. Required: title and registration URL for the next session. Editor reviews the draft. Example has title 'AI for Local Shops' but no URL. Sending is outside this workflow.

## Example result

Create one draft keyed to the transcript ID. With the next-session URL missing, mark it 'needs URL' and assign it to the editor. A retry updates the existing draft. Acceptance: the transcript supports every claim and the editor can see the unresolved link.

## Acceptance check

A second person can complete the dry run, locate the review point and recover from a missing input or repeat run without creating a duplicate.
