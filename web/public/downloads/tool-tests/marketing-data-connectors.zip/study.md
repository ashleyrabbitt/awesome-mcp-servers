# Compare marketing data connectors on the same report

Tested November 22, 2026. Two checks answer different questions. Can a connected account return a known Search Console result? Will a CSV import preserve the campaign identifiers and missing values needed to calculate cost per acquisition?

## What came back from the live connection

We asked GSC Wizard and Supermetrics for Google web search clicks, impressions and average position for the exact search “what review sites compare ai tools using real tasks?” on aisuperpower.cc, October 22 through November 18, inclusive. The earlier observation for this scope supplied our reference: zero clicks, 50 impressions and position 3.04. The date range was settled in the returning connector.

| Connector | Observed output | How to interpret it |
| --- | --- | --- |
| GSC Wizard · Google Search Console | One row. 0 clicks, 50 impressions, 0% CTR, average position 3.04. | All three requested measures matched the earlier observation. The connector reported a live API read. |
| Supermetrics · Google Search Console, connector tool 1.27.88 | Property discovery succeeded. The report call returned TRIAL_EXPIRED and supplied no figures. | Discovery alone could not verify report access. This result leaves numerical agreement unknown. A rerun requires an available query allowance or an active entitlement. |

The measured report calls took about 1.5 and 1.7 seconds respectively on this run. The second figure is time to an access response. Setup, human review time and dollar charges were unmeasured. GSC Wizard did not expose a build number. The live requests used existing authorizations without a new purchase. Readers repeating the live step need access to their own Search Console property. For a different site or date range, supply a reference row from that property's Search Console UI.

[Google Search Analytics method](https://developers.google.com/webmaster-tools/v1/how-tos/search_analytics) · [GSC Wizard](https://www.gscwizard.com/) · [Supermetrics connector](https://supermetrics.com/connectors/google-search-console) · [Supermetrics plan details](https://supermetrics.com/pricing)

## Run the same import without an account

Give the dlt filesystem CSV reader and DuckDB CSV reader the same original eight-row fictional campaign export. Report spend, known conversions and cost per acquisition by campaign for November 9–15. Deduplicate on export_row, retain the exact campaign ID, and leave CPA blank wherever a conversion count is unknown. A zero conversion is a valid reported value. All spend is USD.

The expected answer was set from the fixture before scoring the readers. Six unique in-window rows remain after removing the duplicate A4 and excluding A7.

| Campaign ID | Campaign | Spend | Known conversions | Expected CPA |
| --- | --- | ---: | ---: | ---: |
| 0012 | Launch, East | $100 | 5 | $20 |
| 12 | NA | $50 | 1 | $50 |
| 0360 | Retarget | $15 | 1, plus one unknown row | Unknown |

### Actual outputs and correction work

| Reader and configuration | Checks | What came back |
| --- | ---: | --- |
| dlt 1.32.0 filesystem reader, defaults, pandas 2.2.3 | 3 of 7 | IDs 0012 and 12 both became 12. The label NA became missing. The merged campaign showed $150 spend, 6 conversions and $25 CPA. ID 0360 also became 360. |
| DuckDB 1.4.4 CSV reader, defaults | 7 of 7 | The two IDs stayed distinct, NA stayed text, and all three campaign outputs matched the expected table. |
| dlt with column-specific rules | 7 of 7 | One rerun with three reader settings preserved the identifier as text, kept literal NA and treated blanks only in conversions as missing. All three campaign outputs matched. |
| DuckDB with explicit text types | 7 of 7 | One verification run pinning ID and campaign name to text produced the same three outputs as its default run. No correction was needed on this file. |

The checks covered all eight input rows, exact campaign IDs, literal NA, a quoted comma, the distinction between zero and missing, per-campaign spend, and per-campaign CPA. They are not seven independent statistical observations. The same aggregation code followed both readers, isolating import behavior. Both default runs produced the correct grand total of $165 after filtering. Checking only the total would have missed the merged IDs and incorrect CPA.

Python 3.12.14. Single local reads for default dlt and DuckDB were 82.8 ms and 52.3 ms. Explicit-schema reads were 24.9 ms and 24.9 ms. Times include reader initialization with libraries already imported. The script excludes installation time and downstream aggregation from the timing. These four timings are a run record, not a speed ranking. No person was timed making the correction. The file test needs local Python and the listed open-source packages. No paid spreadsheet service, ad account or AI call was used.

### Reproduce it

1. Put campaign-export.csv and reproduce.py together in a folder.
2. In a Python 3.12 environment run `python -m pip install "dlt[filesystem]==1.32.0" duckdb==1.4.4 pandas==2.2.3`.
3. Run `python reproduce.py > my-results.json`. Compare the rows, rubric and totals with observed.json. Timings vary.
4. Add one new campaign whose ID starts with zero, or change one blank conversion into a known zero. Predict which campaign reports will change before rerunning. Adjust the expected reference values when editing the fixture.

This small example covers read access and file interpretation. It cannot establish the behavior of a live ad-platform integration, incremental refresh, a different export format, a different customer plan or a larger dataset.

[dlt filesystem documentation](https://dlthub.com/docs/dlt-ecosystem/verified-sources/filesystem) · [DuckDB CSV documentation](https://duckdb.org/docs/stable/data/csv/overview)
