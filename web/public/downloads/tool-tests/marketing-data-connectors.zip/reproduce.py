"""Rebuild the marketing CSV results. Run beside campaign-export.csv.
Python 3.12. Install dlt[filesystem]==1.32.0 duckdb==1.4.4 pandas==2.2.3.
"""
import datetime
import hashlib
import json
import math
import os
import platform
from collections import defaultdict
from decimal import Decimal
from pathlib import Path
from time import perf_counter
os.environ.setdefault("RUNTIME__DLTHUB_TELEMETRY", "false")
import dlt
import duckdb
import pandas
from dlt.sources.filesystem import filesystem, read_csv

folder = Path(__file__).resolve().parent
source = folder / "campaign-export.csv"
start, end = "2026-11-09", "2026-11-15"
expected = {
    "0012": {"label": "Launch, East", "spend_usd": "100.00", "known_conversions": 5, "unknown_rows": 0, "cpa_usd": "20.00"},
    "12": {"label": "NA", "spend_usd": "50.00", "known_conversions": 1, "unknown_rows": 0, "cpa_usd": "50.00"},
    "0360": {"label": "Retarget", "spend_usd": "15.00", "known_conversions": 1, "unknown_rows": 1, "cpa_usd": None},
}

def extract_dlt(schema):
    settings = {"dtype": {"campaign_id": "string"}, "keep_default_na": False,
                "na_values": {"conversions": [""]}} if schema else {}
    return list(filesystem(bucket_url=folder.as_uri(), file_glob=source.name) | read_csv(**settings))

def extract_duckdb(schema):
    arguments = ", types={'campaign_id':'VARCHAR','campaign':'VARCHAR'}" if schema else ""
    with duckdb.connect(":memory:") as con:
        result = con.execute("SELECT * FROM read_csv(?"+arguments+")", [str(source)])
        headers = [col[0] for col in result.description]
        return [dict(zip(headers, row, strict=True)) for row in result.fetchall()]

def portable(value):
    if isinstance(value, datetime.date):
        return value.isoformat()
    if isinstance(value, float) and math.isnan(value):
        return None
    return value

def money(amount):
    return format(amount.quantize(Decimal("0.01")), "f")

def summarize(rows):
    groups, seen = defaultdict(list), set()
    for row in rows:
        if not start <= row["date"] <= end or row["export_row"] in seen:
            continue
        seen.add(row["export_row"])
        assert row["currency"] == "USD"
        groups[str(row["campaign_id"])].append(row)
    result = {}
    for key, records in sorted(groups.items()):
        spend = sum(Decimal(str(r["spend"])) for r in records)
        values = [r["conversions"] for r in records]
        known = sum(int(v) for v in values if v is not None)
        unknown = values.count(None)
        result[key] = {"label":records[0]["campaign"], "spend_usd":money(spend),
                       "known_conversions":known, "unknown_rows":unknown,
                       "cpa_usd":money(spend/known) if known and not unknown else None}
    return result

def checks(rows, totals):
    a = {r["export_row"]: r for r in rows}
    return {
        "eight_input_rows_read": len(rows) == 8,
        "exact_campaign_keys_survive": set(totals) == set(expected),
        "literal_NA_label_survives": a["A3"]["campaign"] == "NA",
        "quoted_comma_survives": a["A1"]["campaign"] == "Launch, East",
        "missing_and_zero_remain_distinct": a["A5"]["conversions"] is None and a["A4"]["conversions"] == 0,
        "per_campaign_spend_matches": {k:r["spend_usd"] for k,r in totals.items()} == {k:r["spend_usd"] for k,r in expected.items()},
        "per_campaign_cpa_matches": {k:r["cpa_usd"] for k,r in totals.items()} == {k:r["cpa_usd"] for k,r in expected.items()},
    }

output = {
    "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    "window": [start, end], "versions": {"Python": platform.python_version(), "dlt":dlt.__version__,
    "DuckDB":duckdb.__version__, "pandas":pandas.__version__}, "expected":expected, "runs":[]
}
for name, extractor in [("dlt filesystem CSV reader",extract_dlt),("DuckDB CSV reader",extract_duckdb)]:
    for schema in [False,True]:
        t = perf_counter()
        rows = [{k:portable(v) for k,v in row.items()} for row in extractor(schema)]
        elapsed = perf_counter() - t
        totals = summarize(rows)
        output["runs"].append({"tool":name,"configuration":"explicit" if schema else "default",
            "elapsed_ms_single_local_read":round(elapsed*1000,1),"raw_records":rows,
            "output":totals,"checks":checks(rows,totals)})
        if schema:
            assert totals == expected, (name,totals)
print(json.dumps(output, ensure_ascii=False, indent=2, allow_nan=False))
