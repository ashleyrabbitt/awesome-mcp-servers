#!/usr/bin/env python3
"""Generate four original invoice fixtures and run both local extractors on every file.

Requires Python with ReportLab and Pillow, plus Poppler and Tesseract with English
language data on PATH. Run from any working directory with python invoice_trial.py.
The --existing option uses the PDF files as supplied and reruns extraction only.
"""
import argparse
import hashlib
import io
import json
import os
import re
import subprocess
import tempfile
from pathlib import Path
from statistics import median
from time import perf_counter

from PIL import Image
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen.canvas import Canvas

ROOT = Path(__file__).resolve().parent
INPUTS = ROOT / 'inputs'
OUTPUTS = ROOT / 'outputs'
PDF_SIZE = (420, 490)
MISSING = '<missing>'
CASES = {
    'paper': {
        'supplier': 'North Kite Supply', 'invoice_number': 'DEMO-014',
        'issue_date': '2026-11-02', 'due_date': '2026-12-02', 'purchase_order': None,
        'lines': [('Notebook', '2', '6.00', '12.00'), ('Pen pack', '3', '2.00', '6.00')],
        'subtotal': '18.00', 'tax': '1.26', 'total': '19.26',
    },
    'studio': {
        'supplier': 'Cobalt Studio Goods', 'invoice_number': 'DEMO-028',
        'issue_date': '2026-11-07', 'due_date': '2026-12-07', 'purchase_order': 'PO-1807',
        'lines': [('Canvas pad', '3', '12.50', '37.50'), ('Brush set', '4', '7.25', '29.00')],
        'subtotal': '66.50', 'tax': '3.99', 'total': '70.49',
    },
}
LABELS = {'supplier':'Supplier','invoice_number':'Invoice number','issue_date':'Issued',
          'due_date':'Due date','purchase_order':'Purchase order','subtotal':'Subtotal',
          'tax':'Tax','total':'Total due'}

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

def draw(case, path):
    pdf = Canvas(str(path), pagesize=PDF_SIZE, invariant=1, pageCompression=1)
    pdf.setTitle('Practice invoice ' + case['invoice_number'])
    pdf.setAuthor('AI Superpower')
    pdf.setFillColorRGB(.07,.20,.17)
    pdf.rect(0,425,420,65,stroke=0,fill=1)
    pdf.setFillColorRGB(1,1,1)
    pdf.setFont('InvoiceSansBold',24)
    pdf.drawString(25,451,'Invoice')
    pdf.setFont('InvoiceSans',10)
    pdf.drawRightString(393,452,'AI SUPERPOWER  /  PRACTICE FILE')
    pdf.setFillColorRGB(.1,.14,.13)
    pdf.setFont('InvoiceSans',13)
    for i,key in enumerate(['supplier','invoice_number','issue_date','due_date','purchase_order']):
        pdf.drawString(26,397-23*i,LABELS[key]+': '+(case[key] or ''))
    pdf.setFillColorRGB(.88,.93,.90)
    pdf.rect(25,270,370,22,fill=1,stroke=0)
    pdf.setFillColorRGB(.1,.14,.13)
    pdf.setFont('InvoiceSansBold',10)
    pdf.drawString(31,277,'ITEM')
    for x,title in [(228,'QTY'),(303,'UNIT USD'),(387,'LINE USD')]:
        pdf.drawRightString(x,277,title)
    pdf.setFont('InvoiceSans',12)
    for i,(name,qty,unit,amt) in enumerate(case['lines']):
        y = 250-i*26
        pdf.drawString(31,y,name)
        for x,text in [(226,qty),(303,unit),(387,amt)]:
            pdf.drawRightString(x,y,text)
    pdf.setStrokeColorRGB(.65,.74,.69)
    pdf.line(25,207,395,207)
    for i,key in enumerate(['subtotal','tax','total']):
        pdf.setFont('InvoiceSansBold' if key=='total' else 'InvoiceSans',13)
        pdf.drawString(245,183-24*i,LABELS[key]+':')
        pdf.drawRightString(387,183-24*i,'$'+case[key])
    pdf.setFont('InvoiceSans',10)
    pdf.setFillColorRGB(.22,.33,.28)
    pdf.drawString(25,58,'Currency: USD')
    pdf.drawString(25,40,'Fictional supplier and amounts. For practice only.')
    pdf.showPage()
    pdf.save()

def run_cmd(args):
    return subprocess.run(args,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE).stdout

def render(path, dpi, folder, label):
    prefix=folder/label
    run_cmd(['pdftoppm','-r',str(dpi),'-gray','-png','-singlefile',str(path),str(prefix)])
    return prefix.with_suffix('.png')

def fixtures(folder):
    font_dir=Path(os.environ.get('INVOICE_FONT_DIR','/usr/share/fonts/truetype/dejavu'))
    pdfmetrics.registerFont(TTFont('InvoiceSans',str(font_dir/'DejaVuSans.ttf')))
    pdfmetrics.registerFont(TTFont('InvoiceSansBold',str(font_dir/'DejaVuSans-Bold.ttf')))
    for name,case in CASES.items():
        source=INPUTS/(name+'-digital.pdf')
        draw(case,source)
        img=Image.open(render(source,140,folder,name)).convert('L')
        data=io.BytesIO()
        img.save(data,format='JPEG',quality=70)
        data.seek(0)
        scan=Canvas(str(INPUTS/(name+'-scan.pdf')),pagesize=PDF_SIZE,invariant=1,pageCompression=1)
        scan.setTitle('Image-only practice invoice '+case['invoice_number'])
        scan.setAuthor('AI Superpower')
        scan.drawImage(ImageReader(data),0,0,*PDF_SIZE)
        scan.showPage()
        scan.save()

def reference(case):
    expected={key:case[key] for key in LABELS}
    for i,(name,qty,unit,amount) in enumerate(case['lines'],1):
        expected['line_'+str(i)+'_quantity']=qty
        expected['line_'+str(i)+'_amount']=amount
    return expected

def parse(text,case):
    # Capitalization and spacing of labels are ignored. Values only get trimmed.
    values={}
    for key,label in LABELS.items():
        match=re.search(r'^\s*'+re.escape(label)+r'[ \t]*:[ \t]*(.*)$',text,re.MULTILINE|re.I)
        val=match.group(1).strip() if match else MISSING
        if key in ['subtotal','tax','total']:
            val=val.removeprefix('$').strip()
        values[key]=None if val=='' else val
    # Item descriptions act as row anchors. Extract the adjacent quantity/unit/line total.
    for i,(name,*_) in enumerate(case['lines'],1):
        match=re.search(r'^\s*'+re.escape(name)+r'[ \t]+(\S+)[ \t]+(\S+)[ \t]+(\S+)[ \t]*$',text,re.MULTILINE|re.I)
        values['line_'+str(i)+'_quantity']=match.group(1) if match else MISSING
        values['line_'+str(i)+'_amount']=match.group(3) if match else MISSING
    return values

def trial(path,route,work):
    start=perf_counter()
    if route=='poppler':
        raw=run_cmd(['pdftotext','-layout','-enc','UTF-8',str(path),'-'])
    else:
        img=render(path,300,work,'ocr')
        raw=run_cmd(['tesseract',str(img),'stdout','-l','eng','--psm','6'])
    return raw,(perf_counter()-start)*1000

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--existing',action='store_true')
    args=parser.parse_args()
    INPUTS.mkdir(exist_ok=True)
    OUTPUTS.mkdir(exist_ok=True)
    rows=[]
    write_json(ROOT/'answer-key.json',{k:reference(v) for k,v in CASES.items()})
    with tempfile.TemporaryDirectory() as staging:
        folder=Path(staging)
        if not args.existing:
            fixtures(folder)
        for name,case in CASES.items():
            key=reference(case)
            for form in ['digital','scan']:
                path=INPUTS/(name+'-'+form+'.pdf')
                for route in ['poppler','tesseract']:
                    samples=[trial(path,route,folder) for _ in range(3)]
                    raw=samples[0][0]
                    assert all(output==raw for output,_ in samples), 'Text differed between runs'
                    basename=path.stem+'-'+route
                    (OUTPUTS/(basename+'.txt')).write_bytes(raw)
                    found=parse(raw.decode('utf-8'),case)
                    errors={k:{'expected':v,'observed':found[k]} for k,v in key.items() if v!=found[k]}
                    times=[round(ms,1) for _,ms in samples]
                    rows.append({'file':path.name,'route':route,'correct':len(key)-len(errors),'out_of':len(key),
                                 'median_ms':median(times),'runs_ms':times,'observed':found,'errors':errors,
                                 'raw_file':'outputs/'+basename+'.txt'})
    write_json(ROOT/'results.json',rows)
    write_json(ROOT/'input-hashes.json',{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(INPUTS.glob('*.pdf'))})
    for row in rows:
        print(row['file'],row['route'],row['correct'],'/',row['out_of'],row['median_ms'],'ms',row['errors'].keys())
if __name__=='__main__':
    main()
