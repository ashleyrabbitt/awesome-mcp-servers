"""Separately audit the two unit-price cells excluded from the 12-field score."""
import json
import re
from decimal import Decimal
from pathlib import Path
from invoice_trial import CASES, MISSING, ROOT

audit=[]
for result in json.loads((ROOT/'results.json').read_text()):
    case=CASES[result['file'].split('-')[0]]
    raw=(ROOT/result['raw_file']).read_text()
    for name,qty,unit,line in case['lines']:
        match=re.search(r'^\s*'+re.escape(name)+r'[ \t]+(\S+)[ \t]+(\S+)[ \t]+(\S+)[ \t]*$',raw,re.I|re.M)
        value=match.group(2) if match else MISSING
        balances=None
        if match:
            try:
                balances=Decimal(match.group(1))*Decimal(value)==Decimal(match.group(3))
            except ArithmeticError:
                balances=False
        audit.append({'file':result['file'],'route':result['route'],'item':name,
                      'expected_unit_usd':unit,'observed_unit_usd':value,
                      'unit_correct':value==unit,'line_arithmetic_matches':balances})
(ROOT/'unit-price-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
for route in ['poppler','tesseract']:
    selected=[line for line in audit if line['route']==route]
    print(route,sum(x['unit_correct'] for x in selected),'/',len(selected),'unit prices')
