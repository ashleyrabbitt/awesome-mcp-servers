# AI research synthesis tested on two open papers

**Run date:** November 22, 2026. **Decision:** How should a team test an assistant that answers questions about a long report?

We gave two workflows the same papers and requested two evidence rows, original source locations, a test on our own reports and a limit on generalizing the findings. One workflow used Exa for source retrieval and an AI editor to compose the answer. The other used a TinyFish browser agent to find and synthesize the evidence. We saved the Exa-assisted answer before inspecting the TinyFish result. This was one editorial comparison with different levels of guidance. The reviewer could see the papers, and no independent graders participated.

## The result

| Workflow | Checks passed | Corrections on scored fields | What the run showed |
|---|---:|---:|---|
| Exa retrieval plus AI synthesis | 9/9 | 0 | The Liu landing page omitted the requested baseline. A second retrieval of the full texts found it. The answer preserved the approximate RULER number and cited its abstract. |
| TinyFish browser agent | 7/9 | 2 | It found the baseline and both sample counts. It described the wrong output for Liu’s QA task and reported a rounded fraction as exact. |

Scores describe an editorial checklist for this one prompt. Exa fetch times were 2.15 s and 0.92 s. The TinyFish service reported an 80 s end-to-end run in nine browser steps. The fetch timings exclude drafting and review. No comparable end-to-end timer or manual correction timer was available. Both workflows used existing connected access. Cost per run and underlying hosted model versions were unavailable.

## Follow the evidence

1. **What the model had to produce.** Liu et al. gave a model a question and passages, only one of which contained the answer. A model could find the right passage and still answer incorrectly. TinyFish described identifying the document as the task. The corrected description says that the model had to answer the question using the passages. Source: Section 2.1.
2. **What the number means.** In Table 1, ordinary GPT-3.5-Turbo answered 56.1% correctly without any passages. The separate 16K model has its own row. In certain 20- and 30-document conditions, middle placement fell below the ordinary model’s closed-book result. That does not say every middle placement failed. Source: Section 2.3 and Table 1.
3. **Check “exactly.”** The RULER abstract summarizes the 32K result as about half. TinyFish wrote “exactly half (50 %).” Open Table 3, read the 32K column and count scores above 85.6%, the authors’ baseline. Ten of 17 models clear it. That is 58.8%. The baseline row itself is separate. Both workflows reported 17 models and 13 tasks correctly.
4. **Apply the finding.** Put the same fact at the start, middle and end of three copies of a permitted report and ask the same question. Keep the rest of each version fixed. Score whether the answer and source citation both match the key. These two studies used specific models and controlled tasks. A current tool’s result still needs its own test.

**Primary papers:** [Liu et al., Table 1 and Section 2](https://aclanthology.org/2024.tacl-1.9.pdf) · [Hsieh et al., v3, abstract and Table 3](https://arxiv.org/html/2404.06654v3)

The packet contains the shared prompt, both original synthesis outputs, the extraction log, the scoring key, individual decisions and the 17 published values used for the 32K calculation.
