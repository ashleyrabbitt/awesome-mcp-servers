# Repeat the research synthesis test

Use the question in prompt.txt. Keep the URLs, source versions and wording fixed. Use two separate runs so the second workflow cannot copy the first result.

1. Give both workflows the ACL Anthology page for Liu et al. and the v3 arXiv page for Hsieh et al. Both can read the papers linked by those pages. Other sources are outside the trial.
2. For the first workflow, request both landing pages with Exa web_fetch_exa and a 6,500-character cap per page. Then fetch the Liu PDF and RULER full HTML with a 22,000-character cap. Have an AI editor use that material to write the two rows, follow-up and limitation. Keep that answer alongside the fetch settings. Exa supplies extracted text. The editor writes the synthesis.
3. For the second workflow, give TinyFish run_web_automation the same prompt and the ACL landing page as its starting URL. The prompt includes the RULER page, permits linked full texts and asks for precise locators. Save the returned result. A terminal failure is a workflow observation, never a substitute for a paper finding.
4. Open the two papers independently. Check each submitted answer against reference-key.csv. Record unsupported numbers, overly broad statements and incorrectly named source locations. Give one point per satisfied check. A source-supported “unknown” is better than an invented result, although it does not fill a factual field.
5. Count factual corrections separately from broken or incomplete citations. Record review time with a timer if comparing labor. The original run did not time the editorial review.

The Exa extraction excerpts in this packet preserve the observed table cell and retrieval settings. The full papers remain available at their original URLs. Both tools used existing connected access. Credential details, private execution links and account information are excluded.
